<template>
  <q-layout view="lHh Lpr lFf" class="bg-primary">

    <q-img
      src="background.png"
      class="fit absolute"
    />

    <q-page-container>
      <router-view />
    
    </q-page-container>
  </q-layout>
</template>

